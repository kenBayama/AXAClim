
def read_csv (spark,config): 

    input_data = (spark.read.format("csv") 
    .option("header", True) 
    .option("delimiter",";")
    .load(config["path_raw_data_folder"] + "/" + config["input_file_csv"]))
    return input_data
